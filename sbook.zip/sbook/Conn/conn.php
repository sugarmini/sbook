<?php
	$dsn="mysql:host=localhost;dbname=sbook";
	$username='root';
	$password='';
	$pdo=new PDO($dsn,$username,$password);
	$pdo->query("SET NAMES utf8");
?>
