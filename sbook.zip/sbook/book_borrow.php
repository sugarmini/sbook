<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>享书伴侣后台管理系统</title>
	<link rel="stylesheet" href="book_borrow.css">
	<script type="text/javascript">
		function error(){
			alert("无查询结果");
		}
	</script>
</head>
	
<body>
	<?php include("navigation.php");?>
	<div class="content">
		<div class="articletop">
			<p>图书借还——图书借阅</p>
		</div>
			<div class="reader">
				<form name="form1" method="post" action="">
					<p class="r_confirm">
						读者验证:
						<input type="text" aria-label="请输入读者条形码" placeholder="请输入读者条形码" name='id'>
			    		<input type="submit" value="确定" onclick="submit">
					</p>
				</form>
					<?php 
						include('conn/conn.php');
						if(isset($_POST['id'])){
							$sql="select * from reader_info where id=$_POST[id]";
							$info=$pdo->query($sql)->fetch(PDO::FETCH_ASSOC);
						}else{
							$info=null;
						}
					 ?>
					<div class="articlebottom">
						<div class="line">
		                    <span>姓名 :</span>
		                    <div>
		                        <input type="text" name="name" readonly="readonly" value="<?php echo $info['name'] ?>">
		                    </div>
		                </div>
		                <div class="line">
		                    <span>性别 :</span>
		                    <div>
		                        <input type="text" name="sex" readonly="readonly" value="<?php echo $info['sex'] ?>">
		                    </div>
		                </div>
		                <div class="line">
		                    <span>职业 :</span>
		                    <div><input type="text" name="job" readonly="readonly" value="<?php echo $info['job'] ?>"></div>
		                </div>
		                <div class="line">
		                    <span>出生日期 :</span>
		                    <div><input type="text" name="birthday" readonly="readonly" value="<?php echo $info['birth'] ?>"></div>
		                </div>
						<div class="line">
		                    <span>电话 :</span>
		                    <div><input type="text" name="phone" readonly="readonly" value="<?php echo $info['tel'] ?>"></div>
		                </div>
		                <div class="line">
		                    <span>邮箱 : </span>
		                    <div><input type="text" name="email" readonly="readonly" value="<?php echo $info['email'] ?>"></div>
		                </div>
		                <div class="line">
		                    <span>已借数量（本）：</span>
		                    <div>
		                        <input type="text" name="num" readonly="readonly" value="<?php echo $info['book_account'] ?>">
		                    </div>
		                </div>
					</div>  
				     
		    </div>
		    <div class="book_info">
		    	<form name="form2" method="post" action="">
			    	<div class="means">
				    		<span>添加图书:</span>
				    		<input type="radio" name="bt" class="mean" value="is" checked="checked">ISBN
				    		<input type="radio" name="bt" class="mean" value="na">图书名称
				    		<input type="text" name='key' id='is'>
				    		<input type="submit" value="确定" onclick="submit">
				    		<input type="submit" value="完成借阅">
			    	</div>
		    	</form>
		    	<table  width="98%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#eee" bordercolordark="#D2E3E6" bordercolorlight="#FFFFFF">
					<tr align="center" bgcolor="skyblue">
						<td width="6%" style="padding:3px;">ID</td>
						<td width="13%" style="padding:3px;">ISBN</td>
						<td width="23%" style="padding:3px;">图书名称</td>
						<td width="15%" style="padding:3px;">图书类型</td>
						<td width="14%" style="padding:3px;">出版社</td>
						<td width="12%" style="padding:3px;">书架</td>
						<td width="8%" style="padding:3px;">定价（元）</td>
					</tr>
					<?php 		    			
			    			include("conn/conn.php");
			    			if(isset($_POST['bt'])==FALSE)
			    				$_POST['bt']=null;
			    			if(isset($_POST['key'])==FALSE)
			    				$_POST['key']=null;
			    			$binfos=null;			    			
			    			if($_POST['bt']=='is'){
				    			$sql="select bi.id,isbn,bookName,cate_name,pub_name,shelf_name,price from book_info bi join publishing_house ph on pub_id=ph.id join book_shelf bs on shelf_id=bs.id join book_cate bc on cate_id=bc.id where isbn='$_POST[key]'";
						    	$binfos=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
	    					}else if($_POST['bt']=='na'){
				    			$sql="select bi.id,isbn,bookName,cate_name,pub_name,shelf_name,price from book_info bi join publishing_house ph on pub_id=ph.id join book_shelf bs on shelf_id=bs.id join book_cate bc on cate_id=bc.id where bookName like '%$_POST[key]%'";
						    	$binfos=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);	    			 
		    				}
		    				if($binfos!=null)
		    				foreach($binfos as $binfo){	    			
		    		 	?>
					<tr>
						<td style="padding:5px;" align="center"><?php echo $binfo['id'] ?></td>
						<td style="padding:5px;"><?php echo $binfo['isbn'] ?></td>
						<td style="padding:5px;"><?php echo $binfo['bookName'] ?></td>
						<td style="padding:5px;"><?php echo $binfo['cate_name'] ?></td>
						<td style="padding:5px;"><?php echo $binfo['pub_name'] ?></td>
						<td style="padding:5px;"><?php echo $binfo['shelf_name'] ?></td>
						<td style="padding:5px;"><?php echo $binfo['price'] ?></td>
					</tr>
					<?php } ?>
				</table>
		    </div>
		    </form>
	</div>
</body>
</html>