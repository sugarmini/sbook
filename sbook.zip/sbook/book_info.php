<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>享书伴侣后台管理系统</title>
	<link rel="stylesheet" href="book_borrow.css">
</head>
	
<body>
	<?php include("navigation.php");?>
	<div class="content">
	    <div class="book_info">
	    	<table  width="98%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#eee" bordercolordark="#D2E3E6" bordercolorlight="#FFFFFF" style="margin-top: 10px;">
				<tr align="center" bgcolor="skyblue">
					<td width="6%" style="padding:3px;">ID</td>
					<td width="14%" style="padding:3px;">ISBN</td>
					<td width="12%" style="padding:3px;">图书名称</td>
					<td width="8%" style="padding:3px;">图书类型</td>
					<td width="10%" style="padding:3px;">出版社</td>
					<td width="8%" style="padding:3px;">书架</td>
					<td width="6%" style="padding:3px;">定价（元）</td>
					<td width="8%" style="padding:3px;">借阅时间</td>
					<td width="8%" style="padding:3px;">归还时间</td>
					<td width="6%" style="padding:3px;">修改</td>
					<td width="6%" style="padding:3px;">删除</td>
				</tr>
				<?php 
					include("conn/conn.php");
					$sql="select bi.id,isbn,bookName,cate_name,pub_name,shelf_name,price,borrow_date,return_date from book_info bi join book_cate bc on cate_id=bc.id join publishing_house ph on pub_id=ph.id join book_shelf bs on shelf_id=bs.id join book_borrow on bi.id=book_id where $_GET[id]=bi.id";
					$info=$pdo->query($sql)->fetch(PDO::FETCH_ASSOC);
				 ?>
				<tr>
					<td style="padding:5px;" align="center"><?php echo $info['id'] ?></td>
					<td style="padding:5px;"><?php echo $info['isbn'] ?></td>
					<td style="padding:5px;"><?php echo $info['bookName'] ?></td>
					<td style="padding:5px;"><?php echo $info['cate_name'] ?></td>
					<td style="padding:5px;"><?php echo $info['pub_name'] ?></td>
					<td style="padding:5px;"><?php echo $info['shelf_name'] ?></td>
					<td style="padding:5px;"><?php echo $info['price'] ?></td>
					<td style="padding:5px;" align="center"><?php echo $info['borrow_date'] ?></td>
					<td style="padding:5px;" align="center"><?php echo $info['return_date'] ?></td>
					<td style="padding:5px;" align="center"><a href="book_del_ok.php?id=<?php echo $info['id'] ?>">删除</a></td>
					<td style="padding:5px;" align="center"><a href="book_modify.php?id=<?php echo $info['id'] ?>">修改</a></td>
				</tr>
			</table>
	    </div>
	</div>
</body>
</html>