<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>享书伴侣后台管理系统</title>
	<style>
		.user{
			width: 115px;
			line-height: 28px;
			float: left;
			margin-left: 32px;
			margin-top: 8px;
			color: #0f88eb;
		}
		.content{
			height: 500px;
			background: #fff;
			margin: 0 auto;
		}
		.content table{
			margin: 0 auto;
			margin-top: 3px;
		}
	</style>
</head>
<body>
	<?php include("navigation.php");?>
	<div class="content">
		<div class="user">
			<p>图书借阅排行榜</p>
		</div>
			<table  width="95%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#eee" bordercolordark="#D2E3E6" bordercolorlight="#FFFFFF">
				<tr align="center" bgcolor="skyblue">
					<td width="7%"  style="padding:3px;">排行</td>
					<td width="15%">ISBN码</td>
					<td width="23%">图书名称</td>
					<td width="15%">图书类型</td>
					<td width="14%">出版社</td>
					<td width="12%">书架</td>
					<td width="7%">借阅次数</td>
				</tr>
				<?php 
					include('conn/conn.php');
					$sql="select isbn,bookName,cate_name,pub_name,shelf_name,borrow_account from book_info book join book_cate bc on book.cate_id=bc.id join publishing_house ph on book.pub_id=ph.id join book_shelf bs on book.shelf_id=bs.id join borrow_account on book.id=book_id order by borrow_account desc limit 10";
					$infos=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
					$i=1;
					foreach ($infos as $info) {
				 ?>
				<tr>
					<td align="center" style="padding:5px;"><?php  echo $i ?></td>
					<td style="padding:5px;"><?php  echo $info['isbn'] ?></td>
					<td style="padding:5px;"><?php  echo $info['bookName'] ?></td>
					<td style="padding:5px;"><?php  echo $info['cate_name'] ?></td>
					<td style="padding:5px;"><?php  echo $info['pub_name'] ?></td>
					<td style="padding:5px;"><?php  echo $info['shelf_name'] ?></td>
					<td align="center" style="padding:5px;"><?php  echo $info['borrow_account'] ?></td>
				</tr>
				<?php $i=$i+1;} ?>
			</table>
	</div>
</body>
</html>
