<?php
	header("Context-type:text/html;charset=UTF-8");
	include("conn/conn.php");
	$id=$_GET['id'];
	$sql=$pdo->query("delete from book_info where id='$id'");
	if($sql){
		echo "<script language=javascript>alert('删除成功！');window.location.href='manager.php'</script>";
	}
	else{
		echo "<script language=javascript>alert('删除失败！');history.back();</script>";
	}
?>

