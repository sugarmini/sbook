<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>享书伴侣后台管理系统</title>
	<style>
		.user{
			width: 85px;
			line-height: 28px;
			float: right;
			margin-top: 5px;
		}
		.content{
			height: 500px;
			background: #fff;
			margin: 0 auto;
		}
		.content .top{
			line-height: 30px;
			text-indent: 2em;
			color: #0f88eb;
		}
		.content table{
			margin: 0 auto;
			margin-top: 3px;
		}
	</style>		
</head>
<body>
	<?php include("navigation.php");?>
	<div class="content">
		<div class="top">
			<p>读者管理——读者档案管理——已借图书</p>
		</div>
			<table  width="98%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#eee" bordercolordark="#D2E3E6" bordercolorlight="#FFFFFF">
				<tr align="center" bgcolor="skyblue">
					<td width="6%" style="padding:3px;">ID</td>
					<td width="16%" style="padding:3px;">ISBN</td>
					<td width="26%" style="padding:3px;">图书名称</td>
					<td width="12%" style="padding:3px;">书架</td>
					<td width="12%" style="padding:3px;">借阅时间</td>
					<td width="12%" style="padding:3px;">应还时间</td>
					<td width="6%" style="padding:3px;">状态</td>
					<td width="6%" style="padding:3px;">删除</td>
				</tr>
				<?php 
					include("conn/conn.php");
					$sql="select bb.*,isbn,bookName,shelf_name from book_borrow bb join book_info bi on book_id=bi.id join book_shelf bs on bs.id=bi.shelf_id where reader_id=$_GET[id]";
					$infos=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
					foreach($infos as $info){
				 ?>
				<tr>
					<td style="padding:5px;" align="center"><?php echo $info['book_id'] ?></td>
					<td style="padding:5px;"><?php echo $info['isbn'] ?></td>
					<td style="padding:5px;"><?php echo $info['bookName'] ?></td>
					<td style="padding:5px;"><?php echo $info['shelf_name'] ?></td>
					<td style="padding:5px;" align="center"><?php echo $info['borrow_date'] ?></td>
					<td style="padding:5px;" align="center"><?php echo $info['return_date'] ?></td>
					<td align="center"><?php echo $info['state'] ?></td>
					<td align="center">
						<a href="book_borrow_del.php?id=<?php echo $info['book_id'] ?>">删除</a>
					</td>
				</tr>
				<?php } ?>
			</table>
	</div>
</body>
</html>
