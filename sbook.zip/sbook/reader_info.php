<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>享书伴侣后台管理系统</title>
	<link rel="stylesheet" href="reader_info.css">
</head>
<body>
	<?php include("navigation.php");?>
	<div class="content">
		<div class="articletop">
			<p>读者管理——读者档案管理——查看读者档案</p>
		</div>
		<form name="form1" method="post" action="">
			<div class="articlebottom">
				<?php 
						include('conn/conn.php');
						$sql="select * from reader_info where id=$_GET[id]";
						$info=$pdo->query($sql)->fetch(PDO::FETCH_ASSOC);
						?>
	                <div class="line">
	                    <span>姓名 :</span>
	                    <div>
	                        <input type="text" name="name" readonly="readonly" value="<?php echo $info['name'] ?>">
	                    </div>
		            </div>
	                <div class="line">
	                    <span>性别 :</span>
	                    <div>
	                        <input type="text" name="sex" readonly="readonly" value="<?php echo $info['sex'] ?>">
	                    </div>
	                </div>
	                <div class="line">
		                <span>职业 :</span>
		                <div><input type="text" name="job" readonly="readonly" value="<?php echo $info['job'] ?>"></div>
		            </div>
	                <div class="line">
	                    <span>出生日期 :</span>
	                    <div><input type="text" name="birthday" readonly="readonly" value="<?php echo $info['birth'] ?>"></div>
	                </div>
					<div class="line">
	                    <span>电话 :</span>
	                    <div><input type="text" name="phone" readonly="readonly" value="<?php echo $info['tel'] ?>"></div>
	                </div>
	                <div class="line">
	                    <span>邮箱 : </span>
	                    <div><input type="text" name="email" readonly="readonly" value="<?php echo $info['email'] ?>"></div>
	                </div>
					<div class="line">
						<input type="button" value="返回" onClick="history.back();">
					</div>
	        </div>
	    </form>
	</div>
</body>
</html>