-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1:3306
-- 生成日期： 2019-06-03 20:04:01
-- 服务器版本： 5.7.24
-- PHP 版本： 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `exam`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_no` int(11) NOT NULL AUTO_INCREMENT,
  `admin_email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_pwd` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`admin_no`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `admin`
--

INSERT INTO `admin` (`admin_no`, `admin_email`, `admin_pwd`) VALUES
(1, 'admin@qq.com', '123');

-- --------------------------------------------------------

--
-- 表的结构 `charpter`
--

DROP TABLE IF EXISTS `charpter`;
CREATE TABLE IF NOT EXISTS `charpter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `charpter`
--

INSERT INTO `charpter` (`id`, `name`) VALUES
(1, '第一章'),
(2, '第二章');

-- --------------------------------------------------------

--
-- 表的结构 `comment`
--

DROP TABLE IF EXISTS `comment`;
CREATE TABLE IF NOT EXISTS `comment` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `forum_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `recom_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `comment`
--

INSERT INTO `comment` (`Id`, `forum_id`, `user_id`, `content`, `time`, `recom_id`) VALUES
(1, 1, 1, '回复', '2019-05-23 16:57:42', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `forum`
--

DROP TABLE IF EXISTS `forum`;
CREATE TABLE IF NOT EXISTS `forum` (
  `forum_no` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) DEFAULT NULL,
  `state` int(11) DEFAULT '0' COMMENT '结帖状态',
  PRIMARY KEY (`forum_no`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `forum`
--

INSERT INTO `forum` (`forum_no`, `user_id`, `title`, `content`, `type`, `state`) VALUES
(1, 1, 'test', 'content', NULL, 0);

-- --------------------------------------------------------

--
-- 表的结构 `jd_que`
--

DROP TABLE IF EXISTS `jd_que`;
CREATE TABLE IF NOT EXISTS `jd_que` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub` int(11) NOT NULL,
  `answer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teacher` int(11) NOT NULL,
  `charpter` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `jd_que`
--

INSERT INTO `jd_que` (`id`, `content`, `sub`, `answer`, `teacher`, `charpter`) VALUES
(1, '分析诗经', 1, '题材广泛，语言淳朴自然', 1, 1),
(2, '生物简答题', 2, '生物简答题答案', 1, 1),
(3, '简述《子夜》中林佩瑶的悲剧。', 1, '(1)林佩瑶年青时与雷鸣相恋，情投意合。(1分)但不久后，雷鸣南下开始军旅生涯。(1分)林佩瑶苦等未果，只好嫁给自己不喜欢的吴荪甫。(1分)而吴荪甫独断专行，只顾事业不顾家庭，林佩瑶婚后直空虚寂寞。(1分)与雷鸣的重逢加重了她的痛苦，她只能在抑郁孤独中维持不幸的婚姻。(1分)', 1, 2);

-- --------------------------------------------------------

--
-- 表的结构 `levels`
--

DROP TABLE IF EXISTS `levels`;
CREATE TABLE IF NOT EXISTS `levels` (
  `id` int(11) NOT NULL,
  `lev` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `levels`
--

INSERT INTO `levels` (`id`, `lev`) VALUES
(1, '容易'),
(2, '中等'),
(3, '高难度');

-- --------------------------------------------------------

--
-- 表的结构 `paper_info`
--

DROP TABLE IF EXISTS `paper_info`;
CREATE TABLE IF NOT EXISTS `paper_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `statu` int(11) NOT NULL,
  `mark` int(11) NOT NULL DEFAULT '0',
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `paper_manage`
--

DROP TABLE IF EXISTS `paper_manage`;
CREATE TABLE IF NOT EXISTS `paper_manage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_no` int(11) NOT NULL,
  `paper_no` int(11) NOT NULL,
  `que_type` int(11) NOT NULL,
  `que_no` int(11) NOT NULL COMMENT '在题库中的题号',
  `myans` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `num` int(11) NOT NULL,
  `mymark` int(11) NOT NULL DEFAULT '0',
  `statu` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `que_sub` (`que_type`),
  KEY `paper_no` (`paper_no`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `paper_manage`
--

INSERT INTO `paper_manage` (`id`, `stu_no`, `paper_no`, `que_type`, `que_no`, `myans`, `num`, `mymark`, `statu`) VALUES
(1, 1, 1, 1, 4, 'A', 1, 10, 1),
(2, 1, 1, 1, 11, 'C', 2, 10, 1),
(3, 1, 1, 1, 12, 'A', 3, 10, 1),
(4, 1, 1, 1, 13, 'B', 4, 10, 1),
(5, 1, 1, 1, 6, 'C', 5, 10, 1),
(6, 1, 1, 3, 1, NULL, 6, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `pubpaper`
--

DROP TABLE IF EXISTS `pubpaper`;
CREATE TABLE IF NOT EXISTS `pubpaper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paperno` int(11) NOT NULL,
  `quetype` int(11) NOT NULL,
  `queno` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `pubpaper`
--

INSERT INTO `pubpaper` (`id`, `paperno`, `quetype`, `queno`) VALUES
(1, 1, 1, 4),
(2, 1, 1, 11),
(3, 1, 1, 12),
(4, 1, 1, 13),
(5, 1, 1, 6),
(6, 1, 3, 1),
(7, 2, 1, 6),
(8, 2, 1, 7),
(9, 2, 1, 8),
(10, 2, 1, 14),
(11, 2, 1, 15),
(12, 2, 3, 3),
(13, 3, 1, 4),
(14, 3, 1, 11),
(15, 3, 1, 12),
(16, 3, 1, 13),
(17, 3, 1, 6);

-- --------------------------------------------------------

--
-- 表的结构 `single_question`
--

DROP TABLE IF EXISTS `single_question`;
CREATE TABLE IF NOT EXISTS `single_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '试题编号',
  `content` text COLLATE utf8_unicode_ci NOT NULL COMMENT '考试科目',
  `a_option` text COLLATE utf8_unicode_ci NOT NULL COMMENT '选项内容1',
  `b_option` text COLLATE utf8_unicode_ci NOT NULL COMMENT '选项内容2',
  `c_option` text COLLATE utf8_unicode_ci NOT NULL COMMENT '选项内容3',
  `d_option` text COLLATE utf8_unicode_ci NOT NULL COMMENT '选项内容4',
  `answer` text COLLATE utf8_unicode_ci NOT NULL COMMENT '答案',
  `mark` int(11) NOT NULL,
  `analyse` text COLLATE utf8_unicode_ci NOT NULL,
  `level` int(10) NOT NULL COMMENT '难易度',
  `sub` int(11) NOT NULL,
  `charpter` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `single_question`
--

INSERT INTO `single_question` (`id`, `content`, `a_option`, `b_option`, `c_option`, `d_option`, `answer`, `mark`, `analyse`, `level`, `sub`, `charpter`) VALUES
(1, 'DNA分子在初步水解后，得到的化学物质是', '氨基酸 、葡萄糖、碱基 ', '脱氧核苷酸', '脱氧核糖、碱基、磷酸 ', '核糖核苷酸', 'B', 10, '', 1, 2, 1),
(2, '下面是杜甫的《戏为六绝句》之一，对这首诗分析不正确的一项是', '这首诗中的\"王杨卢骆\"，即指初唐\"四杰\"。', '这首诗评价了\"王杨卢骆\"在诗歌中的作用。', '这首诗否定了对\"王杨卢骆\"哂未休\"的态度和做法。', '这首诗就\"王杨卢骆\"身与名俱灭\"的结局抒发了叹惋之情。', 'D', 10, '解析', 2, 1, 1),
(3, '为了确定某株高茎豌豆(显性)的基因型，最简便的方法是', '让其与矮茎豌豆杂交        ', '让其与另一株高茎豌豆杂交', '让其自交                         ', '直接进行DNA检测', 'C', 10, '', 1, 2, 2),
(4, '下面对《梦江南》赏析有误的一项是', '\"梳洗罢\"才\"独倚望江楼\"，表明她精心打扮，是为了时刻准备心上人的归来。', '\"斜晖脉脉水悠悠\"表面上是写水，实际上也是喻望穿秋水的眼神--那每天不知疲倦地注目的眼神。', '这首词写一女子登楼远眺，盼望归人的情景，表现了她失望和怅惘的情怀。', '温庭筠的这首小词一洗常见的浓艳风格，写得清新淡雅，空灵秀丽，而又朴实自然。后人评价说：\"绝不着力，而款款深深，低徘不尽\"。', 'A', 10, '', 1, 1, 1),
(5, '关于叶肉细胞在光照条件下产生AIP的描述，正确的是', '无氧条件下，光合作用是细胞ATP的唯一来源', '有氧条件下，线粒体、叶绿体和细胞质基质都能产生ATP', '线粒体和叶绿体合成ATP都依赖氧', '细胞质中消耗的ATP均来源于线粒体和叶绿体', 'B', 10, '', 1, 2, 1),
(6, '若无（）事', '齐', '奇', '其', '岐', 'C', 10, '', 1, 1, 2),
(7, '明月（）间照，清泉石上流', '梅', '松', '竹', '兰', 'B', 10, '', 1, 1, 2),
(8, '山下（）芽短浸溪', '梅', '兰', '竹', '菊', 'B', 10, '', 1, 1, 2),
(9, '氢氦（）铍硼', '锂', '碳', '氮', '氧', 'A', 10, '', 1, 2, 2),
(10, '碳（）氧氟氖', '氢', '氮', '氦', '锂', 'B', 10, '', 1, 2, 2),
(11, '东临碣石，以观（）海', '东', '南', '沧', '北', 'C', 10, '', 1, 1, 1),
(12, '山气日夕（），飞鸟相与还', '佳', '奇', '萧', '灿', 'A', 10, '', 1, 1, 1),
(13, '此中有（）意，欲辨已忘言', '实', '真', '心', '人', 'B', 10, '', 1, 1, 1),
(14, '城阙辅（）秦', '一', '二', '三', '四', 'C', 10, '', 1, 1, 2),
(15, '烽烟望（）津', '二', '三', '四', '五', 'D', 10, '', 1, 1, 2);

-- --------------------------------------------------------

--
-- 表的结构 `stupaper`
--

DROP TABLE IF EXISTS `stupaper`;
CREATE TABLE IF NOT EXISTS `stupaper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stuid` int(11) NOT NULL,
  `paperid` int(11) NOT NULL,
  `teaid` int(11) NOT NULL,
  `statu` int(11) NOT NULL,
  `time` datetime DEFAULT NULL,
  `correct` int(11) NOT NULL DEFAULT '0' COMMENT '批改状态',
  `sinmark` int(11) NOT NULL DEFAULT '0',
  `jdmark` int(11) NOT NULL DEFAULT '0',
  `mark` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `stupaper`
--

INSERT INTO `stupaper` (`id`, `stuid`, `paperid`, `teaid`, `statu`, `time`, `correct`, `sinmark`, `jdmark`, `mark`) VALUES
(1, 1, 1, 1, 1, '2019-05-19 15:19:33', 0, 50, 0, 50),
(2, 2, 1, 1, 0, NULL, 0, 0, 0, 0),
(3, 1, 2, 1, 0, NULL, 0, 0, 0, 0),
(4, 2, 2, 1, 0, NULL, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `subjects`
--

DROP TABLE IF EXISTS `subjects`;
CREATE TABLE IF NOT EXISTS `subjects` (
  `sub_no` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`sub_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `subjects`
--

INSERT INTO `subjects` (`sub_no`, `subject`) VALUES
(1, '语文'),
(2, '生物');

-- --------------------------------------------------------

--
-- 表的结构 `teacher`
--

DROP TABLE IF EXISTS `teacher`;
CREATE TABLE IF NOT EXISTS `teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` int(11) NOT NULL,
  `statu` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `teacher`
--

INSERT INTO `teacher` (`id`, `email`, `password`, `subject`, `statu`) VALUES
(1, '1252107636@qq.com', '123456', 1, 1),
(2, 'tea2@qq.com', '123456', 2, 1);

-- --------------------------------------------------------

--
-- 表的结构 `teapaper`
--

DROP TABLE IF EXISTS `teapaper`;
CREATE TABLE IF NOT EXISTS `teapaper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teacher_no` int(11) NOT NULL,
  `statu` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `teapaper`
--

INSERT INTO `teapaper` (`id`, `name`, `subject`, `level`, `teacher_no`, `statu`) VALUES
(1, '第一章测验', '语文', '容易', 1, 1),
(2, '第二章测验', '语文', '容易', 1, 1),
(3, '第一章测验', '语文', '容易', 1, 0);

-- --------------------------------------------------------

--
-- 表的结构 `tiankongti`
--

DROP TABLE IF EXISTS `tiankongti`;
CREATE TABLE IF NOT EXISTS `tiankongti` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ans` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `mark` int(11) NOT NULL,
  `sub` int(11) NOT NULL,
  `charpter` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `tiankongti`
--

INSERT INTO `tiankongti` (`id`, `content`, `ans`, `mark`, `sub`, `charpter`) VALUES
(1, '与君离别意，同是()', '宦游人', 3, 1, 1);

-- --------------------------------------------------------

--
-- 表的结构 `types`
--

DROP TABLE IF EXISTS `types`;
CREATE TABLE IF NOT EXISTS `types` (
  `id` int(11) NOT NULL,
  `ty` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 转存表中的数据 `types`
--

INSERT INTO `types` (`id`, `ty`) VALUES
(1, '单选题'),
(2, '填空题'),
(3, '简答题');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` char(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img` varchar(100) DEFAULT '../../../../LaravelExam/public/images/user_default.jpg',
  `sex` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job` char(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `statu` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `email`, `password`, `name`, `img`, `sex`, `job`, `statu`) VALUES
(1, '1252107636@qq.com', '123456', 'Anny', 'userId1.png', '女', '理科', 1),
(2, 'stu2@qq.com', '123456', 'nex', 'userId2.png', '男', '理科', 1);

-- --------------------------------------------------------

--
-- 表的结构 `user_answer`
--

DROP TABLE IF EXISTS `user_answer`;
CREATE TABLE IF NOT EXISTS `user_answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_no` int(11) NOT NULL,
  `paper_no` int(11) NOT NULL,
  `que_no` int(11) NOT NULL,
  `my_ans` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `que_mark` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `user_paper`
--

DROP TABLE IF EXISTS `user_paper`;
CREATE TABLE IF NOT EXISTS `user_paper` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `user_no` int(11) NOT NULL,
  `paper_no` int(11) NOT NULL,
  `mark` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `ynquestion`
--

DROP TABLE IF EXISTS `ynquestion`;
CREATE TABLE IF NOT EXISTS `ynquestion` (
  `questionno` int(11) NOT NULL AUTO_INCREMENT COMMENT '试题编号',
  `subject` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '考试科目',
  `question` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '试题内容',
  `answer` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '正确答案',
  `analyse` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` int(10) NOT NULL,
  PRIMARY KEY (`questionno`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `ynquestion`
--

INSERT INTO `ynquestion` (`questionno`, `subject`, `question`, `answer`, `analyse`, `level`) VALUES
(1, '1', '我们在HTML页面中制作了一个图像，想要在鼠标指向这个图像时浮出一条提示信息，应该使用pop参数', ' 错误。', '分析', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
