<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>享书伴侣后台管理系统</title>
	<link rel="stylesheet" href="book_borrow.css">
</head>
	
<body>
	<?php include("navigation.php");?>
	<div class="content">
	    <div class="book_info">
	    	<form name="form" method="post" action="">
		    	<div class="means">
		    		<span>查询图书:</span>
		    		<input type="radio" name="bt" class="mean" value="is" checked="checked">ISBN
		    		<input type="radio" name="bt" class="mean" value="na">图书名称
		    		<input type="text" name='key'>
		    		<input type="submit" value="查询">
		    	</div>
	    	</form>
	    	<table  width="98%"  border="1" cellpadding="0" cellspacing="0" bordercolor="#eee" bordercolordark="#D2E3E6" bordercolorlight="#FFFFFF">
				<tr align="center" bgcolor="skyblue">
					<td width="6%" style="padding:3px;">ID</td>
					<td width="13%" style="padding:3px;">ISBN</td>
					<td width="23%" style="padding:3px;">图书名称</td>
					<td width="15%" style="padding:3px;">读者姓名</td>
					<td width="14%" style="padding:3px;">借阅时间</td>
					<td width="14%" style="padding:3px;">归还时间</td>
					<td width="8%" style="padding:3px;">是否归还</td>
				</tr>
				<?php 
	    			include("conn/conn.php");
	    			if(isset($_POST['bt'])==FALSE)
	    				$_POST['bt']=null;
	    			if(isset($_POST['key'])==FALSE)
	    				$_POST['key']=null;
	    			$infos=null;
	    			if($_POST['bt']=='is'){
			    			$sql="select bi.id,isbn,bookName,name,borrow_date,return_date,state from book_info bi join book_borrow on book_id=bi.id join reader_info ri on reader_id=ri.id where isbn='$_POST[key]'";
					    	$infos=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
	    			}else if($_POST['bt']=='na'){
			    			$sql="select bi.id,isbn,bookName,name,borrow_date,return_date,state from book_info bi join book_borrow on book_id=bi.id join reader_info ri on reader_id=ri.id where bookName like '%$_POST[key]%'";
					    	$infos=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);	    			 
		    		}
		    		if($infos!=null)
		    		foreach ($infos as $info) {
    		 	?>	
				<tr>
					<td style="padding:5px;" align="center"><?php echo $info['id'] ?></td>
					<td style="padding:5px;"><?php echo $info['isbn'] ?></td>
					<td style="padding:5px;"><?php echo $info['bookName'] ?></td>
					<td style="padding:5px;"><?php echo $info['name'] ?></td>
					<td style="padding:5px;" align="center"><?php echo $info['borrow_date'] ?></td>
					<td style="padding:5px;" align="center"><?php echo $info['return_date'] ?></td>
					<td align="center"><?php echo $info['state'] ?></td>
				</tr>
				<?php } ?>
			</table>
	    </div>
	</div>
</body>
</html>